var x = 2 + 3;
console.log("Value of x is " + y);