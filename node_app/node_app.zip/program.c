#include <stdio.h>
int main()
{
	int i;
	for(i = 0;i<10;i++)
	{
		printf("Count: %d\n",i);
	}
	return 0;

}